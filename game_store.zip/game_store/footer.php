<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap">
    <title>Document</title>
</head>
<body>

<footer>
    <div class="footer-content">
        <p>&copy; 2024 Game Store</p>
        <p>Contact Us: giorginachkebia977@gmail.com</p>
        <p>Address: 123 Gaming Street, Tbilisi, Georgia</p>
    </div>
</footer>
    
</body>
</html>

